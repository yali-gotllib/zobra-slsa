# Zobra

A simple Python package for SLSA (Supply-chain Levels for Software Artifacts) provenance demonstration.

## Overview

Zobra is a minimal Python package created to demonstrate SLSA provenance generation and verification workflows. It provides basic file operations that can be used to showcase supply chain security practices.

## Installation

### From Source

```bash
git clone https://github.com/wiz-sec/zobra.git
cd zobra
pip install -e .
```

### For Development

```bash
git clone https://github.com/wiz-sec/zobra.git
cd zobra
pip install -e ".[dev]"
```

## Usage

### Basic Usage

```python
import zobra

# Create a file with default content
zobra.dump_file('foo.txt')

# Create a file with custom content
zobra.dump_file('custom.txt', 'Hello, SLSA!')

# Read a file
content = zobra.read_file('foo.txt')
print(content)

# Get package version
version = zobra.get_version()
print(f"Zobra version: {version}")
```

### Command Line Usage

After installation, you can also use zobra from the command line:

```bash
python -c "import zobra; zobra.dump_file('example.txt')"
```

## 🔒 SLSA Security Implementation

This package demonstrates **SLSA Level 3** provenance generation using GitHub's native attestation system.

### Verification

Verify the package integrity using GitHub CLI:

```bash
# Download the package
pip download zobra --no-deps

# Verify SLSA attestation
gh attestation verify zobra-*.whl --repo wiz-sec/zobra
```

### Comprehensive Verification

Run our complete verification script:

```bash
./verify_slsa_complete.sh
```

### SLSA Demonstration Scenarios

This package supports the following SLSA demonstration scenarios:

1. **✅ Create package + verify**: Generate SLSA provenance and verify with GitHub CLI
2. **✅ Existing package + has SLSA + verify succeeds**: Demonstrate successful verification
3. **❌ Existing package + no SLSA + verify failed**: Show verification failure without provenance
4. **❌ Create package with broken SLSA + verify failed**: Demonstrate verification failure with invalid provenance

### Security Properties

Our implementation provides:
- **Build Integrity**: Cryptographic proof of build process
- **Source Authenticity**: Verification of source repository
- **Transparency**: Public record in Rekor transparency log
- **Non-Repudiation**: Immutable build attestation

## Features

- Simple file creation with `dump_file()`
- File reading with `read_file()`
- Version information retrieval
- Automatic timestamp and metadata inclusion
- Type hints for better development experience
- Comprehensive error handling

## Development

### Running Tests

```bash
pytest
```

### Code Formatting

```bash
black zobra/
```

### Type Checking

```bash
mypy zobra/
```

## License

MIT License - see LICENSE file for details.

## Contributing

This is a demonstration package for SLSA provenance workflows. Contributions are welcome for educational purposes.

## 📚 Documentation

- **[SLSA Implementation Details](SLSA_IMPLEMENTATION.md)** - Comprehensive guide to our SLSA setup
- **[Release Process](create_release.md)** - How to create releases with SLSA provenance
- **[Verification Scripts](verify_slsa_complete.sh)** - Complete verification workflow

## About SLSA

SLSA (Supply-chain Levels for Software Artifacts) is a security framework that helps protect software supply chains. Learn more at [slsa.dev](https://slsa.dev/).
